
// Ports
sc_in <bool> clock;
sc_in <bool> reset;
sc_in <bool> start;
sc_in <int> in1;
sc_in <int> in2;
sc_in <int> in3;
sc_in <int> in4;
sc_out<bool> done;


// Variables
int share_mem[100];
bool write_done;

// Process Declaration
void Prc1();
void Prc2();

// Constructor (?)



// Process Registration (?)
// SC_CTHREAD(Prc1,clock.pos());
 //reset_signal_is(reset,true);
// SC_CTHREAD(Prc2,clock.pos());
// reset_signal_is(reset,true);
